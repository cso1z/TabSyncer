const e="recent_session_recovery_changed";export{e as R};
