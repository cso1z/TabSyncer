const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./statsStore-CvNJ-Qgw.js","./languageStartup-D-fjOoRt.js","./language-CJod-mLS.js","./languageStartup-BhyKBIh7.css","./group-QqMDzXhV.js","../main.js","./modulepreload-polyfill-B5Qt9EMX.js","./main-CRr6241a.css","./el-popper-BgL5vYb2.js","./el-popper-Wf_ds9r7.css","./group-S7fQQ3B8.css"])))=>i.map(i=>d[i]);
import{E as ve}from"./index-Dn1RMr_O.js";import{E as xe}from"./el-dialog-Bosvsk0w.js";import{d1 as O,e as $e,i as we,x as ye,l as b,ar as D,a7 as x,at as d,ab as p,f as L,aw as N,aQ as _e,a9 as R,j as q,aa as E,ac as Se,v as m,r as y,_ as ke}from"./languageStartup-D-fjOoRt.js";import{_ as Z}from"../main.js";import"./el-popper-BgL5vYb2.js";import"./language-CJod-mLS.js";import"./modulepreload-polyfill-B5Qt9EMX.js";function B(t={},e){const a=Ee(t),r=Ce(t,a),n=Le(a);return{...r,formatSnapshotCount:n.formatSnapshotCount,formatWebPageCount:n.formatWebPageCount,formatMarkdownSummary:(o,c,s)=>n.formatMarkdownSummary(r,o,c,s),formatSingleHtmlSummary:n.formatSingleHtmlSummary,formatListHtmlSummary:n.formatListHtmlSummary,formatCreatedAt:n.formatCreatedAt,formatDownloadedFile:n.formatDownloadedFile,formatProcessingFile:n.formatProcessingFile,formatDownloadButton:n.formatDownloadButton}}function Ce(t,e){const a=M(t.snapshotExport)?t.snapshotExport:{},r=e in O?e:"en",n={...O[r]};for(const[c,s]of Object.entries(a))typeof s=="string"&&s.trim()&&c in n&&(n[c]=s);const o=M(t.snapshot)?t.snapshot:{};return n.unnamedSnapshot=K(o,"unnamed",n.unnamedSnapshot),n}function Le(t){switch(t){case"zh":return{formatSnapshotCount:e=>`${e} 个快照`,formatWebPageCount:e=>`${e} 个网页`,formatMarkdownSummary:(e,a,r,n)=>[`> ${e.markdownExportLabel} - ${n.slice(0,16).replace("T"," ")}`,`> ${a} 个快照 - ${r} 个网页`],formatSingleHtmlSummary:(e,a,r)=>`${e} 个网页 - 创建于 ${l(a)} - 导出于 ${l(r)}`,formatListHtmlSummary:(e,a,r)=>`${e} 个快照 - ${a} 个网页 - 导出于 ${l(r)}`,formatCreatedAt:e=>`创建于 ${l(e)}`,formatDownloadedFile:e=>`${e} 已开始下载`,formatProcessingFile:e=>`正在生成 ${e.toUpperCase()} 文件。`,formatDownloadButton:e=>`下载 .${e}`};case"ru":return{formatSnapshotCount:e=>`${e} снимков`,formatWebPageCount:e=>`${e} веб-страниц`,formatMarkdownSummary:(e,a,r,n)=>[`> ${e.markdownExportLabel} - ${n.slice(0,16).replace("T"," ")}`,`> ${a} снимков - ${r} веб-страниц`],formatSingleHtmlSummary:(e,a,r)=>`${e} веб-страниц - Создано ${l(a)} - Экспортировано ${l(r)}`,formatListHtmlSummary:(e,a,r)=>`${e} снимков - ${a} веб-страниц - Экспортировано ${l(r)}`,formatCreatedAt:e=>`Создано: ${l(e)}`,formatDownloadedFile:e=>`Загрузка файла ${e} началась`,formatProcessingFile:e=>`Создание файла ${e.toUpperCase()}.`,formatDownloadButton:e=>`Скачать .${e}`};case"fr":return{formatSnapshotCount:e=>`${e} ${e>1?"instantanés":"instantané"}`,formatWebPageCount:e=>`${e} ${e>1?"pages web":"page web"}`,formatMarkdownSummary:(e,a,r,n)=>[`> ${e.markdownExportLabel} - ${n.slice(0,16).replace("T"," ")}`,`> ${a} ${a>1?"instantanés":"instantané"} - ${r} ${r>1?"pages web":"page web"}`],formatSingleHtmlSummary:(e,a,r)=>`${e} ${e>1?"pages web":"page web"} - Créé ${l(a)} - Exporté ${l(r)}`,formatListHtmlSummary:(e,a,r)=>`${e} ${e>1?"instantanés":"instantané"} - ${a} ${a>1?"pages web":"page web"} - Exporté ${l(r)}`,formatCreatedAt:e=>`Créé : ${l(e)}`,formatDownloadedFile:e=>`Téléchargement de ${e} démarré`,formatProcessingFile:e=>`Génération du fichier ${e.toUpperCase()}.`,formatDownloadButton:e=>`Télécharger .${e}`};case"es":return{formatSnapshotCount:e=>`${e} ${e===1?"instantánea":"instantáneas"}`,formatWebPageCount:e=>`${e} ${e===1?"página web":"páginas web"}`,formatMarkdownSummary:(e,a,r,n)=>[`> ${e.markdownExportLabel} - ${n.slice(0,16).replace("T"," ")}`,`> ${a} ${a===1?"instantánea":"instantáneas"} - ${r} ${r===1?"página web":"páginas web"}`],formatSingleHtmlSummary:(e,a,r)=>`${e} ${e===1?"página web":"páginas web"} - Creado ${l(a)} - Exportado ${l(r)}`,formatListHtmlSummary:(e,a,r)=>`${e} ${e===1?"instantánea":"instantáneas"} - ${a} ${a===1?"página web":"páginas web"} - Exportado ${l(r)}`,formatCreatedAt:e=>`Creado: ${l(e)}`,formatDownloadedFile:e=>`La descarga de ${e} ha comenzado`,formatProcessingFile:e=>`Generando archivo ${e.toUpperCase()}.`,formatDownloadButton:e=>`Descargar .${e}`};case"ar":return{formatSnapshotCount:e=>`${e} لقطة`,formatWebPageCount:e=>`${e} صفحة ويب`,formatMarkdownSummary:(e,a,r,n)=>[`> ${e.markdownExportLabel} - ${n.slice(0,16).replace("T"," ")}`,`> ${a} لقطة - ${r} صفحة ويب`],formatSingleHtmlSummary:(e,a,r)=>`${e} صفحة ويب - أُنشئت ${l(a)} - صُدّرت ${l(r)}`,formatListHtmlSummary:(e,a,r)=>`${e} لقطة - ${a} صفحة ويب - صُدّرت ${l(r)}`,formatCreatedAt:e=>`أُنشئت: ${l(e)}`,formatDownloadedFile:e=>`بدأ تنزيل ${e}`,formatProcessingFile:e=>`جارٍ إنشاء ملف ${e.toUpperCase()}.`,formatDownloadButton:e=>`تنزيل .${e}`};case"en":default:return{formatSnapshotCount:e=>`${e} ${e===1?"snapshot":"snapshots"}`,formatWebPageCount:e=>`${e} ${e===1?"web page":"web pages"}`,formatMarkdownSummary:(e,a,r,n)=>[`> ${e.markdownExportLabel} - ${n.slice(0,16).replace("T"," ")}`,`> ${a} ${a===1?"snapshot":"snapshots"} - ${r} ${r===1?"web page":"web pages"}`],formatSingleHtmlSummary:(e,a,r)=>`${e} ${e===1?"web page":"web pages"} - Created ${l(a)} - Exported ${l(r)}`,formatListHtmlSummary:(e,a,r)=>`${e} ${e===1?"snapshot":"snapshots"} - ${a} ${a===1?"web page":"web pages"} - Exported ${l(r)}`,formatCreatedAt:e=>`Created: ${l(e)}`,formatDownloadedFile:e=>`${e} download started`,formatProcessingFile:e=>`Generating ${e.toUpperCase()} file.`,formatDownloadButton:e=>`Download .${e}`}}}function Ee(t){const e=t.__lang;if(e==="zh"||e==="en"||e==="ru"||e==="fr"||e==="es"||e==="ar")return e;if(typeof document<"u"){const n=document.documentElement.lang||"";if(n.startsWith("zh"))return"zh";if(n.startsWith("en"))return"en";if(n.startsWith("ru"))return"ru";if(n.startsWith("fr"))return"fr";if(n.startsWith("es"))return"es";if(n.startsWith("ar"))return"ar"}const a=M(t.list)?t.list:{},r=K(a,"title","");return/[\u4e00-\u9fff]/.test(r)?"zh":"en"}function K(t,e,a){const r=t[e];return typeof r=="string"&&r.trim()?r:a}function M(t){return typeof t=="object"&&t!==null}function l(t){if(!t)return"";const e=new Date(t);return Number.isNaN(e.getTime())?String(t):`${e.getFullYear()}-${F(e.getMonth()+1)}-${F(e.getDate())} ${F(e.getHours())}:${F(e.getMinutes())}`}function F(t){return String(t).padStart(2,"0")}const Te=`data:image/svg+xml,${encodeURIComponent('<svg width="128" height="128" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="64" cy="64" r="60" fill="#2563eb" stroke="#fff" stroke-width="8"/><circle cx="64" cy="64" r="36" fill="#fff" stroke="#2563eb" stroke-width="6"/><path d="M64 64L64 32" stroke="#ea4335" stroke-width="6" stroke-linecap="round"/><path d="M64 64L92 80" stroke="#34a853" stroke-width="6" stroke-linecap="round"/><path d="M64 64L36 80" stroke="#fbbc05" stroke-width="6" stroke-linecap="round"/><circle cx="64" cy="64" r="14" fill="#2563eb" stroke="#fff" stroke-width="4"/></svg>')}`;function J(t,e,a=B()){return e==="json"?je(t,a):e==="html"?He(t,a):Fe(t,a)}function ee(t){return t==="json"?"json":t==="html"?"html":"md"}function Ae(t){return t==="json"?"application/json;charset=utf-8":t==="html"?"text/html;charset=utf-8":"text/markdown;charset=utf-8"}function De(t,e){const a=new Date(t.exportedAt),r=`${a.getFullYear()}${Q(a.getMonth()+1)}${Q(a.getDate())}`;return`tabsyncer-${t.scope.type==="all"?"all-snapshots":`${t.scope.type}-${Oe(t.scope.label)}`}-${r}.${ee(e)}`}function Fe(t,e){const a=[`# ${z(Pe(t,e))}`,"",...e.formatMarkdownSummary(t.snapshotCount,t.tabCount,t.exportedAt),""];if(t.scope.type==="snapshot")X(a,t.snapshots[0],e),Y(a,_(t.snapshots[0]),e);else for(const r of t.snapshots)a.push(`## ${z(A(r,e))}`),a.push(""),a.push(`- ${e.formatCreatedAt(r.createdAt)}`),X(a,r,e,!1),a.push(`- ${e.webPageCountLabel}: ${_(r).length}`),a.push(""),Y(a,_(r),e),a.push("");return a.join(`
`).trimEnd()+`
`}function Pe(t,e){return t.scope.type==="snapshot"?A(t.snapshots[0],e)||t.scope.label:t.scope.label||e.allSnapshots}function Y(t,e,a){t.push(`| # | ${a.tableTitleLabel} | ${a.tableLinkLabel} |`),t.push("|---:|---|---|"),e.forEach((r,n)=>{t.push(`| ${n+1} | ${G(P(r,a))} | ${G(r.url||"")} |`)})}function X(t,e,a,r=!0){const n=T(e);n&&(t.push(`- ${a.noteLabel}: ${G(n)}`),r&&t.push(""))}function He(t,e){const a=t.scope.type==="snapshot"?A(t.snapshots[0],e):t.scope.label||e.allSnapshots,n=t.scope.type==="snapshot"?Ne(t,a,e):Me(t,a,e),o=typeof document<"u"&&document.documentElement.lang||"en";return`<!doctype html>
<html lang="${S(o)}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/svg+xml" href="${Te}">
  <title>${u(a)} - ${u(e.htmlTitleSuffix)}</title>
  <style>
    :root {
      color-scheme: light;
      --bg: #f4f7f6;
      --panel: #ffffff;
      --panel-soft: #f8fbfa;
      --border: #dbe7e4;
      --border-strong: #b9d8d0;
      --text: #1f2d2b;
      --muted: #6b7d79;
      --accent: #0f8f7a;
      --accent-soft: #e8f6f3;
      --shadow: 0 14px 40px rgba(24, 58, 52, 0.08);
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background:
        radial-gradient(circle at 12% 0%, rgba(15, 143, 122, 0.12), transparent 28%),
        linear-gradient(180deg, #f8fbfa 0%, var(--bg) 100%);
      color: var(--text);
      font-family: ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      line-height: 1.6;
    }
    a { color: inherit; text-decoration: none; }
    .export-shell {
      width: min(1080px, calc(100% - 32px));
      margin: 0 auto;
      padding: 36px 0 48px;
    }
    .hero {
      margin-bottom: 20px;
      padding: 26px 28px;
      border: 1px solid var(--border);
      border-radius: 22px;
      background: rgba(255, 255, 255, 0.88);
      box-shadow: var(--shadow);
    }
    .hero__eyebrow {
      margin: 0 0 8px;
      color: var(--accent);
      font-size: 13px;
      font-weight: 700;
      letter-spacing: 0.02em;
    }
    .hero h1 {
      margin: 0;
      font-size: clamp(26px, 4vw, 38px);
      line-height: 1.18;
    }
    .hero__summary {
      margin: 12px 0 0;
      color: var(--muted);
      font-size: 15px;
    }
    .group-tabs {
      position: sticky;
      top: 0;
      z-index: 2;
      display: flex;
      gap: 10px;
      margin: 0 0 18px;
      padding: 10px;
      overflow-x: auto;
      border: 1px solid var(--border);
      border-radius: 18px;
      background: rgba(255, 255, 255, 0.88);
      backdrop-filter: blur(14px);
      box-shadow: 0 10px 26px rgba(24, 58, 52, 0.06);
    }
    .group-tab {
      flex: 0 0 auto;
      padding: 8px 14px;
      border: 1px solid transparent;
      border-radius: 999px;
      background: transparent;
      color: var(--muted);
      cursor: pointer;
      font: inherit;
      font-size: 14px;
      font-weight: 700;
    }
    .group-tab.is-active {
      border-color: var(--border-strong);
      background: var(--accent-soft);
      color: #0b6658;
    }
    .snapshot-list {
      display: grid;
      gap: 16px;
    }
    .snapshot-card,
    .snapshot-detail-card {
      border: 1px solid var(--border);
      border-radius: 18px;
      background: var(--panel);
      box-shadow: 0 8px 24px rgba(24, 58, 52, 0.05);
      overflow: hidden;
    }
    .snapshot-card__header,
    .snapshot-detail-card__header {
      display: flex;
      width: 100%;
      justify-content: space-between;
      gap: 16px;
      padding: 18px 20px;
      color: inherit;
      border-bottom: 1px solid var(--border);
      background: var(--panel-soft);
      font: inherit;
      text-align: left;
    }
    .snapshot-card__header {
      align-items: flex-start;
      border: 0;
      cursor: pointer;
    }
    .snapshot-card__header:hover {
      background: #f2faf7;
    }
    .snapshot-card[data-collapsed="false"] .snapshot-card__header {
      border-bottom: 1px solid var(--border);
    }
    .snapshot-card h2,
    .snapshot-detail-card h2 {
      margin: 0;
      font-size: 18px;
      line-height: 1.35;
    }
    .snapshot-card__meta,
    .snapshot-detail-card__meta {
      flex: 0 0 auto;
      color: var(--muted);
      font-size: 13px;
      white-space: nowrap;
    }
    .snapshot-card__submeta,
    .snapshot-detail-card__submeta {
      margin-top: 6px;
      color: var(--muted);
      font-size: 13px;
    }
    .snapshot-card__note,
    .snapshot-detail-card__note {
      max-width: 640px;
      margin: 8px 0 0;
      color: var(--muted);
      font-size: 13px;
      line-height: 1.55;
      white-space: pre-wrap;
    }
    .snapshot-card__actions {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      flex: 0 0 auto;
    }
    .snapshot-card__toggle {
      display: inline-flex;
      align-items: center;
      padding: 5px 10px;
      border: 1px solid var(--border-strong);
      border-radius: 999px;
      color: #0b6658;
      background: #fff;
      font-size: 12px;
      font-weight: 800;
      white-space: nowrap;
    }
    .tab-list {
      margin: 0;
      padding: 0;
      list-style: none;
    }
    .tab-row {
      display: grid;
      grid-template-columns: 26px minmax(0, 1fr);
      gap: 12px;
      padding: 13px 20px;
      border-top: 1px solid #edf3f1;
    }
    .tab-row:first-child { border-top: 0; }
    .tab-row:hover { background: #fbfdfc; }
    .tab-row__icon {
      width: 26px;
      height: 26px;
      border-radius: 7px;
      object-fit: cover;
      background: #edf5f3;
    }
    .tab-row__fallback {
      display: inline-grid;
      place-items: center;
      color: #0b6658;
      font-size: 12px;
      font-weight: 800;
    }
    .tab-row__title {
      display: block;
      overflow: hidden;
      color: var(--text);
      font-size: 15px;
      font-weight: 700;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .tab-row__url {
      display: block;
      overflow: hidden;
      margin-top: 3px;
      color: var(--muted);
      font-size: 13px;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .empty-state {
      padding: 28px;
      border: 1px dashed var(--border-strong);
      border-radius: 18px;
      color: var(--muted);
      background: rgba(255, 255, 255, 0.74);
      text-align: center;
    }
    @media (max-width: 720px) {
      .export-shell { width: min(100% - 20px, 1080px); padding-top: 18px; }
      .hero { padding: 20px; border-radius: 18px; }
      .snapshot-card__header,
      .snapshot-detail-card__header {
        display: block;
      }
      .snapshot-card__actions {
        margin-top: 10px;
      }
      .snapshot-card__meta,
      .snapshot-detail-card__meta {
        display: block;
        margin-top: 8px;
      }
      .tab-row { padding: 12px 14px; }
    }
  </style>
</head>
<body>
${n}
</body>
</html>
`}function Ne(t,e,a){const r=t.snapshots[0],n=_(r),o=T(r);return`  <main class="export-shell export-shell--single">
    ${te({title:e,eyebrow:a.htmlEyebrow,summary:a.formatSingleHtmlSummary(n.length,r==null?void 0:r.createdAt,t.exportedAt)})}
    <section class="snapshot-detail-card">
      <div class="snapshot-detail-card__header">
        <div>
          <h2>${u(e)}</h2>
          <div class="snapshot-detail-card__submeta">${u(a.savedPageTitles)}</div>
          ${o?`<p class="snapshot-detail-card__note">${u(o)}</p>`:""}
        </div>
        <span class="snapshot-detail-card__meta">${u(a.formatWebPageCount(n.length))}</span>
      </div>
      ${ae(n,a)}
    </section>
  </main>`}function Me(t,e,a){const r=Ue(t,a),n=r.length>1,o=t.snapshots.map(c=>ze(c,a)).join(`
`);return`  <main class="export-shell export-shell--list">
    ${te({title:e,eyebrow:a.htmlEyebrow,summary:a.formatListHtmlSummary(t.snapshotCount,t.tabCount,t.exportedAt)})}
    ${n?Be(r,a):""}
    <section class="snapshot-list">
${o||`      <div class="empty-state">${u(a.emptySnapshots)}</div>`}
    </section>
  </main>
  ${Ie(a)}`}function te(t){return`<header class="hero">
      <p class="hero__eyebrow">${u(t.eyebrow)}</p>
      <h1>${u(t.title)}</h1>
      <p class="hero__summary">${u(t.summary)}</p>
    </header>`}function ze(t,e){const a=_(t),r=re(t,e),n=T(t);return`      <article class="snapshot-card" data-group-name="${S(r)}" data-collapsed="true">
        <button class="snapshot-card__header" type="button" data-snapshot-toggle aria-expanded="false">
          <div>
            <h2>${u(A(t,e))}</h2>
            <div class="snapshot-card__submeta">${u(e.formatCreatedAt(t==null?void 0:t.createdAt))}</div>
            ${n?`<p class="snapshot-card__note">${u(n)}</p>`:""}
          </div>
          <span class="snapshot-card__actions">
            <span class="snapshot-card__meta">${u(e.formatWebPageCount(a.length))}</span>
            <span class="snapshot-card__toggle">${u(e.expand)}</span>
          </span>
        </button>
        <div class="snapshot-card__body" data-snapshot-body hidden>
          ${ae(a,e)}
        </div>
      </article>`}function ae(t,e){return t.length===0?`<div class="empty-state">${u(e.emptyTabs)}</div>`:`<ul class="tab-list">
${t.map(a=>`        <li class="tab-row">
          ${Ge(a,e)}
          <a href="${S(a.url||"#")}" target="_blank" rel="noopener noreferrer">
            <span class="tab-row__title">${u(P(a,e))}</span>
            <span class="tab-row__url">${u(Ve(a.url||""))}</span>
          </a>
        </li>`).join(`
`)}
      </ul>`}function Ge(t,e){if(t.favIconUrl)return`<img class="tab-row__icon" src="${S(t.favIconUrl)}" alt="">`;const a=P(t,e).trim().slice(0,1).toUpperCase()||"#";return`<span class="tab-row__icon tab-row__fallback">${u(a)}</span>`}function Be(t,e){const a=["all",...t];return`<nav class="group-tabs" aria-label="${S(e.groupFilterAriaLabel)}">
${a.map((r,n)=>{const o=r==="all"?e.allFilterLabel:r;return`      <button class="group-tab${n===0?" is-active":""}" type="button" data-group-filter="${S(r)}">${u(o)}</button>`}).join(`
`)}
    </nav>`}function Ie(t){return`  <script>
    (function () {
      var buttons = Array.prototype.slice.call(document.querySelectorAll('[data-group-filter]'));
      var cards = Array.prototype.slice.call(document.querySelectorAll('[data-group-name]'));
      var toggles = Array.prototype.slice.call(document.querySelectorAll('[data-snapshot-toggle]'));
      function toggleSnapshotCard(card) {
        var shouldExpand = card.dataset.collapsed !== 'false';
        var body = card.querySelector('[data-snapshot-body]');
        var button = card.querySelector('[data-snapshot-toggle]');
        var label = card.querySelector('.snapshot-card__toggle');
        card.dataset.collapsed = shouldExpand ? 'false' : 'true';
        if (body) body.hidden = !shouldExpand;
        if (button) button.setAttribute('aria-expanded', String(shouldExpand));
        if (label) label.textContent = shouldExpand ? ${JSON.stringify(t.collapse)} : ${JSON.stringify(t.expand)};
      }
      function setActiveGroup(group) {
        buttons.forEach(function (button) {
          button.classList.toggle('is-active', button.dataset.groupFilter === group);
        });
        cards.forEach(function (card) {
          card.hidden = group !== 'all' && card.dataset.groupName !== group;
        });
      }
      toggles.forEach(function (button) {
        button.addEventListener('click', function () {
          var card = button.closest('[data-collapsed]');
          if (card) toggleSnapshotCard(card);
        });
      });
      buttons.forEach(function (button) {
        button.addEventListener('click', function () {
          setActiveGroup(button.dataset.groupFilter || 'all');
        });
      });
      window.setActiveGroup = setActiveGroup;
      window.toggleSnapshotCard = toggleSnapshotCard;
    })();
  <\/script>`}function Ue(t,e){const a=[];for(const r of t.snapshots){const n=re(r,e);a.includes(n)||a.push(n)}return a}function re(t,e){return(t==null?void 0:t.groupName)||(t==null?void 0:t.group)||((t==null?void 0:t.groupId)==null?e.ungrouped:e.unnamedGroup)}function je(t,e){return JSON.stringify({source:"TabSyncer",exportedAt:t.exportedAt,scope:{type:t.scope.type,label:t.scope.label},snapshotCount:t.snapshotCount,tabCount:t.tabCount,snapshots:t.snapshots.map(a=>({name:A(a,e),...T(a)?{note:T(a)}:{},createdAt:a.createdAt,group:We(t.scope,a,e),tabs:_(a).map(r=>({title:P(r,e),url:r.url||""}))}))},null,2)}function A(t,e){return(t==null?void 0:t.name)||e.unnamedSnapshot}function T(t){return typeof(t==null?void 0:t.note)=="string"?t.note.trim():""}function _(t){return Array.isArray(t==null?void 0:t.tabs)?t.tabs.filter(e=>!(e!=null&&e.deleted)):[]}function P(t,e){return(t==null?void 0:t.title)||(t==null?void 0:t.url)||e.untitledPage}function Ve(t){if(!t)return"";try{const e=new URL(t);return`${e.hostname}${e.pathname==="/"?"":e.pathname}`}catch{return t}}function We(t,e,a){return t.type==="group"?t.label:(e==null?void 0:e.groupName)||(e==null?void 0:e.group)||((e==null?void 0:e.groupId)==null?a.temporarySnapshot:"")}function Q(t){return String(t).padStart(2,"0")}function Oe(t){return t.trim().replace(/[\\/:*?"<>|\s]+/g,"-").replace(/^-+|-+$/g,"")||"export"}function z(t){return t.replace(/[[\]\\]/g,"\\$&")}function G(t){return z(t).replace(/\|/g,"\\|").replace(/\r?\n/g,"<br>").trim()}function u(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function S(t){return u(t).replace(/`/g,"&#96;")}const Re=100;async function qe(t){const e=t.getSnapshotList||Je,a=t.pageSize||Re,r=t.i18n||B(),n=t.scope.type==="snapshot"?[t.scope.snapshot]:await Xe({scope:t.scope,pageSize:a,getSnapshotList:e}),o=await Ze({snapshots:n,scope:t.scope,getGroupList:t.getGroupList||Ye,i18n:r});return{exportedAt:new Date().toISOString(),scope:t.scope,snapshotCount:o.length,tabCount:o.reduce((c,s)=>c+Qe(s).length,0),snapshots:o}}async function Je(...t){const{getSnapshotList:e}=await Z(async()=>{const{getSnapshotList:a}=await import("./statsStore-CvNJ-Qgw.js").then(r=>r.y);return{getSnapshotList:a}},__vite__mapDeps([0,1,2,3]),import.meta.url);return e(...t)}async function Ye(){const{getGroupList:t}=await Z(async()=>{const{getGroupList:e}=await import("./group-QqMDzXhV.js").then(a=>a.b);return{getGroupList:e}},__vite__mapDeps([4,1,2,3,5,6,7,8,9,10]),import.meta.url);return t()}async function Xe(t){var r;const e=[];let a;for(;;){const n=await t.getSnapshotList({view:t.scope.type==="group"?"group":"all",...t.scope.type==="group"?{groupId:t.scope.groupId}:{},...a!==void 0?{lastId:a}:{},pageSize:t.pageSize}),o=Array.isArray(n)?n:[];if(e.push(...o),o.length<t.pageSize||(a=(r=o[o.length-1])==null?void 0:r.id,a===void 0))break}return e}function Qe(t){return Array.isArray(t==null?void 0:t.tabs)?t.tabs.filter(e=>!(e!=null&&e.deleted)):[]}async function Ze(t){if(t.scope.type==="snapshot")return t.snapshots;if(t.scope.type==="group")return t.snapshots.map(r=>({...r,groupName:t.scope.label}));if(!t.snapshots.some(r=>(r==null?void 0:r.groupId)!=null))return t.snapshots.map(r=>({...r,groupName:t.i18n.ungrouped}));const e=await t.getGroupList(),a=new Map((Array.isArray(e)?e:[]).filter(r=>(r==null?void 0:r.id)!=null).map(r=>[Number(r.id),r.name||t.i18n.unnamedGroup]));return t.snapshots.map(r=>({...r,groupName:(r==null?void 0:r.groupId)==null?t.i18n.ungrouped:a.get(Number(r.groupId))||t.i18n.unnamedGroup}))}function Ke(t,e,a){const r=new Blob([a],{type:Ae(e)}),n=URL.createObjectURL(r),o=document.createElement("a");return o.href=n,o.download=De(t,e),document.body.appendChild(o),o.click(),o.remove(),window.setTimeout(()=>URL.revokeObjectURL(n),0),o.download}const et={class:"export-summary"},tt={class:"export-summary__content"},at={class:"export-counts"},rt={key:1},ot={class:"export-format"},nt={class:"export-format__grid"},st=["disabled","onClick"],lt=2*1024*1024,it=$e({__name:"SnapshotExportDialog",props:{modelValue:{type:Boolean},scope:{}},emits:["update:modelValue"],setup(t,{emit:e}){const a=t,r=e,n=we("i18n",{}),o=m(()=>B(n)),c=y("markdown"),s=y("idle"),g=y(null),$=y(""),w=y(""),h=y(!1),oe=m(()=>[{value:"markdown",label:"Markdown",description:o.value.formatMarkdownDescription},{value:"html",label:"HTML",description:o.value.formatHtmlDescription},{value:"json",label:"JSON",description:o.value.formatJsonDescription}]),H=m({get:()=>a.modelValue,set:i=>r("update:modelValue",i)}),k=m(()=>s.value==="loading"||s.value==="processing"),ne=m(()=>s.value==="completed"||s.value==="failed"),I=m(()=>s.value==="ready"||s.value==="completed"||s.value==="failed"),se=m(()=>{var i;return((i=a.scope)==null?void 0:i.label)||o.value.snapshotLabel}),le=m(()=>{var i,f;return((i=a.scope)==null?void 0:i.type)==="all"?o.value.dialogTitleAll:((f=a.scope)==null?void 0:f.type)==="group"?o.value.dialogTitleGroup:o.value.dialogTitleSnapshot}),ie=m(()=>{var i,f;return((i=a.scope)==null?void 0:i.type)==="all"?o.value.scopeDescriptionAll:((f=a.scope)==null?void 0:f.type)==="group"?o.value.scopeDescriptionGroup:o.value.scopeDescriptionSnapshot}),U=m(()=>g.value?J(g.value,"markdown",o.value):""),ue=m(()=>new Blob([U.value]).size),j=m(()=>ue.value>=lt),ce=m(()=>s.value==="failed"?o.value.statusFailed:s.value==="completed"?h.value?o.value.statusCopied:o.value.statusDownloaded:s.value==="processing"?o.value.statusProcessing:s.value==="ready"?o.value.statusReady:o.value.statusLoadingData),V=m(()=>s.value==="failed"?$.value||o.value.statusFailedText:s.value==="completed"?w.value?o.value.formatDownloadedFile(w.value):o.value.statusCompletedCopyText:s.value==="processing"?c.value==="markdown"?o.value.formatProcessingFile("markdown"):o.value.formatProcessingFile(c.value):s.value==="ready"?o.value.statusReadyText:o.value.statusLoadingData),de=m(()=>s.value==="completed"?o.value.downloadAgain:o.value.formatDownloadButton(ee(c.value)));ye(()=>[a.modelValue,a.scope],([i,f])=>{i&&f&&W(f)},{immediate:!0});async function W(i){s.value="loading",g.value=null,$.value="",w.value="",h.value=!1,c.value="markdown";try{g.value=await qe({scope:i,i18n:o.value}),s.value="ready"}catch{$.value=o.value.statusLoadFailedText,s.value="failed"}}async function pe(){if(!(!g.value||j.value)){s.value="processing",h.value=!1;try{await navigator.clipboard.writeText(U.value),h.value=!0,w.value="",s.value="completed"}catch{$.value=o.value.statusCopyFailedText,s.value="failed"}}}function me(){if(g.value){s.value="processing",h.value=!1;try{const i=J(g.value,c.value,o.value);w.value=Ke(g.value,c.value,i),s.value="completed"}catch{$.value=o.value.statusFailedText,s.value="failed"}}}function fe(i){!I.value||c.value===i||(c.value=i,(s.value==="completed"||s.value==="failed")&&(s.value="ready",w.value="",h.value=!1,$.value=""))}function ge(){a.scope&&W(a.scope)}function be(){H.value=!1}return(i,f)=>{const C=ve,he=xe;return b(),D(he,{modelValue:H.value,"onUpdate:modelValue":f[0]||(f[0]=v=>H.value=v),title:le.value,width:"620px",class:"snapshot-export-dialog","close-on-click-modal":!k.value},{footer:x(()=>[q(C,{disabled:k.value,onClick:be},{default:x(()=>[E(p(ne.value?o.value.close:o.value.cancel),1)]),_:1},8,["disabled"]),s.value==="failed"?(b(),D(C,{key:0,type:"primary",onClick:ge},{default:x(()=>[E(p(o.value.retry),1)]),_:1})):g.value?(b(),L(N,{key:1},[c.value==="markdown"?(b(),D(C,{key:0,disabled:k.value||j.value,onClick:pe},{default:x(()=>[E(p(h.value?o.value.copyAgain:o.value.copyMarkdown),1)]),_:1},8,["disabled"])):Se("",!0),q(C,{type:"primary",loading:k.value,onClick:me},{default:x(()=>[E(p(de.value),1)]),_:1},8,["loading"])],64)):(b(),D(C,{key:2,type:"primary",disabled:""},{default:x(()=>[E(p(k.value?o.value.loading:o.value.preparing),1)]),_:1}))]),default:x(()=>[d("section",et,[d("div",tt,[d("strong",null,p(se.value),1),d("p",null,p(ie.value),1)])]),d("section",at,[g.value?(b(),L(N,{key:0},[d("span",null,p(o.value.formatSnapshotCount(g.value.snapshotCount)),1),d("span",null,p(o.value.formatWebPageCount(g.value.tabCount)),1)],64)):(b(),L("span",rt,p(V.value),1))]),d("section",ot,[d("h3",null,p(o.value.formatSectionTitle),1),d("div",nt,[(b(!0),L(N,null,_e(oe.value,v=>(b(),L("button",{key:v.value,type:"button",class:R(["export-format__card",{"is-active":c.value===v.value}]),disabled:!I.value,onClick:ut=>fe(v.value)},[f[1]||(f[1]=d("span",{class:"export-format__radio"},null,-1)),d("strong",null,p(v.label),1),d("small",null,p(v.description),1)],10,st))),128))])]),d("section",{class:R(["export-status",`is-${s.value}`])},[d("strong",null,p(ce.value),1),d("span",null,p(V.value),1)],2)]),_:1},8,["modelValue","title","close-on-click-modal"])}}}),ht=ke(it,[["__scopeId","data-v-38f5a3ce"]]);export{ht as default};
